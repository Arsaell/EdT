package DATA;

import java.util.HashMap;
import java.util.List;

public abstract class Constrainable	{

}
