package DATA;

public interface People	{

	public String getMail();
}
