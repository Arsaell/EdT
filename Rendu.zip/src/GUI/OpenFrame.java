package GUI;

import javax.swing.JInternalFrame;

public class OpenFrame extends JInternalFrame {

	
	public OpenFrame() {
		super();
		setBounds(100, 100, 450, 300);
		this.setVisible(true);

	}

}
